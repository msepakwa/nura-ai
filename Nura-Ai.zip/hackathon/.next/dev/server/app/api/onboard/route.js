var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/onboard/route.js")
R.c("server/chunks/node_modules_next_1ne155dcvypez._.js")
R.c("server/chunks/[root-of-the-server]__0gpgvtib7i2o8._.js")
R.c("server/chunks/_next-internal_server_app_api_onboard_route_actions_1s65c838x264o.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/onboard/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/onboard/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
