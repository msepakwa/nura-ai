module.exports = [
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/app/api/state/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/engine.ts [app-route] (ecmascript)");
;
;
;
async function GET() {
    const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readDB"])();
    const user = db.user;
    const mode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["determineMode"])(user);
    user.mode = mode;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        user: {
            ...user,
            chat: db.chat
        },
        mode,
        insights: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getInsights"])(user),
        nextActions: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getNextActions"])(user),
        reframe: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$engine$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["identityReframe"])(user)
    });
}
}),
"[project]/src/lib/engine.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyCheckInAdaptation",
    ()=>applyCheckInAdaptation,
    "classifySetbackCause",
    ()=>classifySetbackCause,
    "determineMode",
    ()=>determineMode,
    "getInsights",
    ()=>getInsights,
    "getNextActions",
    ()=>getNextActions,
    "identityReframe",
    ()=>identityReframe,
    "recommendLevel",
    ()=>recommendLevel,
    "recoverySuggestion",
    ()=>recoverySuggestion
]);
function getInsights(state, habitId) {
    const checks = (habitId ? state.checkIns.filter((c)=>c.habitId === habitId) : state.checkIns).slice().sort((a, b)=>a.date.localeCompare(b.date));
    const recent = checks.slice(-14);
    const total = recent.length;
    const done = recent.filter((c)=>c.status === "done" || c.status === "smaller").length;
    const completionRate = total ? done / total : 0;
    let recentMissStreak = 0;
    for(let i = checks.length - 1; i >= 0; i--){
        if (checks[i].status === "skip") recentMissStreak++;
        else break;
    }
    let recentDoneStreak = 0;
    for(let i = checks.length - 1; i >= 0; i--){
        if (checks[i].status !== "skip") recentDoneStreak++;
        else break;
    }
    const reasonCounts = {};
    for (const c of recent.filter((c)=>c.status === "skip" && c.reason)){
        const r = c.reason.toLowerCase();
        reasonCounts[r] = (reasonCounts[r] || 0) + 1;
    }
    const topSkipReasons = Object.entries(reasonCounts).sort((a, b)=>b[1] - a[1]).slice(0, 3).map(([r])=>r);
    let risk = "low";
    if (recentMissStreak >= 3 || total >= 5 && completionRate < 0.35) risk = "high";
    else if (recentMissStreak >= 1 || total >= 4 && completionRate < 0.6) risk = "medium";
    return {
        total,
        done,
        completionRate,
        recentMissStreak,
        recentDoneStreak,
        topSkipReasons,
        risk
    };
}
function determineMode(state) {
    if (state.recovery.active) return "recover";
    const insights = getInsights(state);
    if (insights.risk === "high") return "recover";
    if (insights.recentDoneStreak >= 5 && insights.completionRate >= 0.7) return "maintain";
    return "build";
}
function classifySetbackCause(reason, note) {
    const text = `${reason || ""} ${note || ""}`.toLowerCase();
    if (/tired|exhaust|sleep|energy|burn/.test(text)) return "energy";
    if (/busy|work|meeting|time|no time|schedule/.test(text)) return "time";
    if (/forgot|remember/.test(text)) return "forgetfulness";
    if (/travel|sick|ill|injur|pain|family|kids/.test(text)) return "disruption";
    if (/motivat|don't feel|didn't feel|not me|lazy|pointless/.test(text)) return "motivation/identity";
    if (/place|gym|weather|space|environment/.test(text)) return "environment";
    return "unspecified";
}
function recoverySuggestion(cause, habit) {
    const tiny = habit?.tiny || "a 2-minute version of your habit";
    switch(cause){
        case "energy":
            return `Energy was low. For 24–72h, do only the minimum: ${tiny}. Rest counts as support.`;
        case "time":
            return `Time was tight. Shrink the habit to ${tiny} and attach it to an existing routine.`;
        case "forgetfulness":
            return `It slipped your mind. Use an if-then cue and a single gentle prompt at a reliable time.`;
        case "disruption":
            return `Life disrupted your plan. That's normal. Restart with ${tiny} when ready—no catch-up needed.`;
        case "motivation/identity":
            return `This felt misaligned. Reconnect to your future self: do ${tiny} as proof of who you're becoming, not a test.`;
        case "environment":
            return `Your environment got in the way. Make ${tiny} possible where you are (no special setup).`;
        default:
            return `Setbacks happen. Reset with ${tiny}—smallest step, no judgment, then rebuild gradually.`;
    }
}
function recommendLevel(state, habit) {
    const insights = getInsights(state, habit.id);
    const mode = state.recovery.active ? "recover" : determineMode(state);
    if (mode === "recover" || insights.risk === "high" || insights.recentMissStreak >= 2) return "tiny";
    if (mode === "maintain" && insights.completionRate > 0.8 && insights.recentDoneStreak >= 5) return "standard";
    if (insights.completionRate >= 0.6) return "small";
    return "tiny";
}
function getNextActions(state) {
    const mode = determineMode(state);
    const actions = [];
    for (const habit of state.habits.filter((h)=>h.active)){
        const level = recommendLevel(state, habit);
        const action = level === "tiny" ? habit.tiny : level === "small" ? habit.small : habit.standard;
        let reason = "Sized to your current rhythm.";
        if (mode === "recover") reason = "Recovery mode: smallest win to rebuild momentum.";
        else if (mode === "maintain") reason = "Maintenance mode: protect consistency with a sustainable dose.";
        else if (getInsights(state, habit.id).risk === "medium") reason = "A lighter step to keep you moving without overload.";
        actions.push({
            habitId: habit.id,
            habitName: habit.name,
            level,
            action,
            ifThen: habit.ifThen,
            reason,
            mode
        });
    }
    return actions.slice(0, 3);
}
function identityReframe(state) {
    const fsSelf = state.identity.futureSelf || "your healthier self";
    const val = state.identity.values[0];
    const base = `Each small action is evidence that you are becoming ${fsSelf}.`;
    if (val) return `${base} This honors your value of ${val}.`;
    return base;
}
function applyCheckInAdaptation(state, checkIn) {
    // mutate-friendly copy assumptions handled by caller; update habit levels and recovery
    const habit = state.habits.find((h)=>h.id === checkIn.habitId);
    if (checkIn.status === "skip") {
        const cause = classifySetbackCause(checkIn.reason, checkIn.note);
        const misses = getInsights(state, checkIn.habitId).recentMissStreak; // includes this in effect? state already has it
        if (misses >= 2) {
            state.recovery.active = true;
            state.recovery.cause = cause;
            state.recovery.startedAt = state.recovery.startedAt || new Date().toISOString();
            state.recovery.plan = recoverySuggestion(cause, habit);
            state.recovery.rampStep = 0;
            if (habit) habit.currentLevel = "tiny";
        } else if (habit) {
            habit.currentLevel = "tiny";
        }
    } else {
        // success: progress recovery ramp or maintain
        if (state.recovery.active) {
            state.recovery.rampStep = (state.recovery.rampStep || 0) + 1;
            if (state.recovery.rampStep >= 2) {
                state.recovery.active = false;
                state.recovery.cause = undefined;
                state.recovery.plan = undefined;
                state.recovery.rampStep = 0;
            } else if (habit) {
                habit.currentLevel = "small";
            }
        } else if (habit) {
            const insights = getInsights(state, habit.id);
            if (insights.completionRate > 0.8 && insights.recentDoneStreak >= 4) habit.currentLevel = "standard";
            else if (insights.completionRate > 0.5) habit.currentLevel = "small";
        }
    }
    state.mode = determineMode(state);
    return state;
}
}),
"[project]/src/lib/store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "readDB",
    ()=>readDB,
    "todayStr",
    ()=>todayStr,
    "uid",
    ()=>uid,
    "updateDB",
    ()=>updateDB,
    "writeDB",
    ()=>writeDB
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const DATA_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), "data");
const DB_PATH = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(DATA_DIR, "db.json");
function defaultUser() {
    return {
        onboarded: false,
        goal: "",
        identity: {
            futureSelf: "",
            values: [],
            barriers: [],
            constraints: "",
            tone: "gentle"
        },
        habits: [],
        checkIns: [],
        reflections: [],
        recovery: {
            active: false,
            rampStep: 0
        },
        mode: "build"
    };
}
function defaultDB() {
    return {
        user: defaultUser(),
        chat: []
    };
}
function readDB() {
    try {
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(DATA_DIR)) __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].mkdirSync(DATA_DIR, {
            recursive: true
        });
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(DB_PATH)) {
            const db = defaultDB();
            __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
            return db;
        }
        const raw = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(DB_PATH, "utf-8");
        const parsed = JSON.parse(raw);
        // basic migration safety
        if (!parsed.user) parsed.user = defaultUser();
        if (!parsed.chat) parsed.chat = [];
        return parsed;
    } catch  {
        return defaultDB();
    }
}
function writeDB(db) {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(DATA_DIR)) __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].mkdirSync(DATA_DIR, {
        recursive: true
    });
    __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
}
function updateDB(mutator) {
    const db = readDB();
    mutator(db);
    writeDB(db);
    return db;
}
function todayStr() {
    return new Date().toISOString().slice(0, 10);
}
function uid() {
    return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1wjt7adhj2opm._.js.map