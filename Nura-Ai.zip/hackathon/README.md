# NURA — AI-Powered Healthy Behavior & Lifestyle Management Platform

NURA is an **adaptive health companion** that helps people **build healthy habits, maintain them, and recover from setbacks without judgment**. It goes beyond reminders by understanding behavior patterns, identity challenges, and context—then continuously adapting its support.

> *Not reminders. A relationship with your healthier self.*

## Core capabilities (addresses all 5 requirements)

| Requirement | How NURA implements it |
|---|---|
| **Understand behavior** | Tracks check-ins/events, computes follow-through, momentum, risk, and recurring friction patterns over time. |
| **Understand identity challenges** | Captures future self, values, barriers, constraints, and tone; reframes actions as identity-aligned evidence. |
| **Build healthy habits** | Tiny-habit scaffolding with if-then plans and three difficulty levels (tiny/small/standard). |
| **Maintain habits** | Mode-aware adaptation (Build/Maintain) that protects consistency and right-sizes effort as patterns stabilize. |
| **Recover from setbacks** | Drift/setback detection, compassionate Recovery Mode, cause classification, minimum-viable recovery plan, and gradual ramp-back. |

**Continuous adaptation loop:** *Sense → Understand → Support → Learn* (every check-in updates mode, difficulty, and recommendations).

## What’s in this implementation

A working full-stack prototype (Next.js App Router + TypeScript + Tailwind) with:

- **Identity-aware onboarding** (goal, future self, values, barriers, constraints, coach tone)
- **Adaptive habit & plan** (if-then cue, tiny/small/standard variants)
- **Daily dashboard** with mode badge (Build/Maintain/Recover) and “next best” actions sized to readiness
- **Quick check-ins**: Done / Did smaller / Skip or struggled (with barrier capture)
- **Adaptive engine** (`src/lib/engine.ts`): behavior insights, risk & drift detection, mode selection, level recommendation, setback cause classification, recovery planning, and post-check-in adaptation
- **Recovery flow**: compassionate reset, minimum viable plan, ramp-back after wins (no streak-shame)
- **AI coach chat** (`src/lib/coach.ts`): non-judgmental, context/identity-aware responses and reflective guidance (rule-based, LLM-pluggable)
- **Behavior insights & identity reframing** (patterns and meaning, not punishment)
- **Local persistence** via JSON store (`data/db.json`) for demo simplicity

## Architecture (prototype)

```text
[ Next.js Web UI ]  (src/app/page.tsx)
        │  fetch
        ▼
[ API Routes ]      /api/state, /api/onboard, /api/checkin, /api/recover, /api/chat
        │
        ├── [ AI/Adaptation Engine ]  src/lib/engine.ts  (behavior, identity, recovery, recommendations)
        ├── [ Coach ]                 src/lib/coach.ts   (adaptive, non-judgmental responses)
        └── [ Data Store ]            src/lib/store.ts   (JSON persistence, swappable for DB)
```

**Production-ready target architecture (from proposal):** React/Next + RN clients → API gateway/BFF → core services (user, habits, check-ins, scheduling, analytics) + AI engine (behavior modeling, NLP/identity, recommender/bandit, recovery planner, guardrailed LLM orchestrator) → PostgreSQL + time-series + Redis + vector DB, with wearable/calendar/notification integrations and security controls (TLS, encryption at rest, RBAC, granular consent, minimization, audit, AI safety).

## Getting started

### Prerequisites
- Node.js 18+ and npm

### Install & run
```bash
npm install
npm run dev
```
Open [http://localhost:3000](http://localhost:3000).

### Build
```bash
npm run build
npm start
```

## Demo flow
1. **Onboard:** set a goal, future self/values/barriers, and a first tiny habit with an if-then plan.
2. **Act:** view adaptive next steps and check in (Done / Smaller / Skip).
3. **Adaptation:** log a few skips or choose “compassionate reset” to see **Recovery Mode** and minimum-viable planning.
4. **Learn:** observe insights, identity reframing, and coach responses adapt to your patterns.

## Safety & privacy notes
- Coaching is **not medical advice**; no diagnosis or prescriptive medical claims.
- Designed for **data minimization, granular consent, and non-judgmental** interaction. Prototype stores data locally in `data/db.json`.

## Project structure
- `src/app/page.tsx` – UI (onboarding, dashboard, recovery, insights, coach)
- `src/app/api/*` – state, onboarding, check-in, recovery, chat endpoints
- `src/lib/types.ts` – domain model
- `src/lib/store.ts` – persistence
- `src/lib/engine.ts` – behavior/identity understanding & adaptive/recovery logic
- `src/lib/coach.ts` – AI coach responses
- `data/db.json` – local demo data (created on first run)
