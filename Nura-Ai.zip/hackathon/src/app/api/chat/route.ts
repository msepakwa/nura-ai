import { NextResponse } from "next/server";
import { updateDB } from "@/lib/store";
import { generateCoachReply } from "@/lib/coach";

export async function POST(req: Request) {
  const body = await req.json();
  const { message } = body as { message: string };
  if (!message || !message.trim()) return NextResponse.json({ error: "message required" }, { status: 400 });

  let reply = "";
  const db = updateDB((db) => {
    const now = new Date().toISOString();
    db.chat.push({ role: "user", content: message.trim(), createdAt: now });
    reply = generateCoachReply(db.user, message.trim());
    db.chat.push({ role: "assistant", content: reply, createdAt: new Date().toISOString() });
  });

  return NextResponse.json({ ok: true, reply, chat: db.chat });
}
