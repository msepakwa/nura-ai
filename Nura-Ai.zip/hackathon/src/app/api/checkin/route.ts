import { NextResponse } from "next/server";
import { updateDB, uid, todayStr } from "@/lib/store";
import { applyCheckInAdaptation, determineMode } from "@/lib/engine";
import { CheckIn } from "@/lib/types";

export async function POST(req: Request) {
  const body = await req.json();
  const { habitId, status, reason, note } = body as {
    habitId: string;
    status: "done" | "smaller" | "skip";
    reason?: string;
    note?: string;
  };
  if (!habitId || !status) return NextResponse.json({ error: "habitId and status required" }, { status: 400 });

  const db = updateDB((db) => {
    const check: CheckIn = {
      id: uid(),
      habitId,
      date: todayStr(),
      status,
      reason,
      note,
      createdAt: new Date().toISOString(),
    };
    db.user.checkIns.push(check);
    applyCheckInAdaptation(db.user, check);
    db.user.mode = determineMode(db.user);
  });

  return NextResponse.json({ ok: true, user: db.user, mode: db.user.mode, recovery: db.user.recovery });
}
