import { NextResponse } from "next/server";
import { updateDB } from "@/lib/store";
import { IdentityProfile } from "@/lib/types";

export async function POST(req: Request) {
  const body = await req.json();
  const patch = body as Partial<IdentityProfile>;

  const db = updateDB((db) => {
    if (typeof patch.constraints === "string") {
      db.user.identity.constraints = patch.constraints.trim();
    }
    if (Array.isArray(patch.barriers)) {
      db.user.identity.barriers = patch.barriers.filter((b): b is string => typeof b === "string" && b.trim().length > 0).map(b => b.trim());
    }
    if (typeof patch.futureSelf === "string") {
      db.user.identity.futureSelf = patch.futureSelf.trim();
    }
  });

  return NextResponse.json({ ok: true, identity: db.user.identity });
}
