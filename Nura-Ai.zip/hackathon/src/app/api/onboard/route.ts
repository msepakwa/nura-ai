import { NextResponse } from "next/server";
import { updateDB, uid } from "@/lib/store";
import { Habit, IdentityProfile } from "@/lib/types";

export async function POST(req: Request) {
  const body = await req.json();
  const { goal, identity, habit } = body as {
    goal: string;
    identity: IdentityProfile;
    habit: { name: string; domain: string; ifThen: string; tiny: string; small: string; standard: string };
  };

  if (!goal || !identity || !habit?.name) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  const db = updateDB((db) => {
    db.user.goal = goal;
    db.user.identity = {
      futureSelf: identity.futureSelf || "",
      values: Array.isArray(identity.values) ? identity.values.filter(Boolean) : [],
      barriers: Array.isArray(identity.barriers) ? identity.barriers.filter(Boolean) : [],
      constraints: identity.constraints || "",
      tone: identity.tone || "gentle",
    };
    const newHabit: Habit = {
      id: uid(),
      name: habit.name,
      domain: habit.domain || "wellbeing",
      ifThen: habit.ifThen || "",
      tiny: habit.tiny || `2 minutes of ${habit.name}`,
      small: habit.small || `5 minutes of ${habit.name}`,
      standard: habit.standard || habit.name,
      currentLevel: "tiny",
      active: true,
      createdAt: new Date().toISOString(),
    };
    // replace habits on onboarding for simplicity
    db.user.habits = [newHabit];
    db.user.onboarded = true;
    db.user.mode = "build";
    db.user.recovery = { active: false, rampStep: 0 };
    db.chat = [{
      role: "assistant",
      content: `Welcome. I’m NURA. I’ll help you become ${db.user.identity.futureSelf || "the person you want to be"} with support that adapts to your behavior, identity, and setbacks—without judgment. Your first focus: ${newHabit.name}.`,
      createdAt: new Date().toISOString(),
    }];
  });

  return NextResponse.json({ ok: true, user: db.user });
}
