import { NextResponse } from "next/server";
import { updateDB } from "@/lib/store";
import { classifySetbackCause, recoverySuggestion, determineMode } from "@/lib/engine";

export async function POST(req: Request) {
  const body = await req.json();
  const { action, causeText } = body as { action: "start" | "resolve" | "pause"; causeText?: string };

  const db = updateDB((db) => {
    const habit = db.user.habits.find(h => h.active);
    if (action === "resolve") {
      db.user.recovery = { active: false, rampStep: 0 };
      if (habit) habit.currentLevel = "small";
    } else if (action === "start") {
      const cause = classifySetbackCause(causeText);
      db.user.recovery = {
        active: true,
        startedAt: new Date().toISOString(),
        cause,
        plan: recoverySuggestion(cause, habit),
        rampStep: 0,
      };
      if (habit) habit.currentLevel = "tiny";
    } else if (action === "pause") {
      db.user.recovery = { ...db.user.recovery, active: false };
    }
    db.user.mode = determineMode(db.user);
  });

  return NextResponse.json({ ok: true, user: db.user, recovery: db.user.recovery });
}
