import { NextResponse } from "next/server";
import { readDB } from "@/lib/store";
import { getInsights, getNextActions, determineMode, identityReframe } from "@/lib/engine";

export async function GET() {
  const db = readDB();
  const user = db.user;
  const mode = determineMode(user);
  user.mode = mode;
  return NextResponse.json({
    user: { ...user, chat: db.chat },
    mode,
    insights: getInsights(user),
    nextActions: getNextActions(user),
    reframe: identityReframe(user),
  });
}
