"use client";

import { useEffect, useMemo, useState } from "react";

type Mode = "build" | "maintain" | "recover";

type NextAction = {
  habitId: string;
  habitName: string;
  level: "tiny" | "small" | "standard";
  action: string;
  ifThen: string;
  reason: string;
  mode: Mode;
};

type Insights = {
  total: number;
  done: number;
  completionRate: number;
  recentMissStreak: number;
  recentDoneStreak: number;
  topSkipReasons: string[];
  risk: "low" | "medium" | "high";
};

type AppState = {
  user: any;
  mode: Mode;
  insights: Insights;
  nextActions: NextAction[];
  reframe: string;
};

function Badge({ mode }: { mode: Mode }) {
  const styles: Record<Mode, string> = {
    build: "bg-blue-100 text-blue-800",
    maintain: "bg-emerald-100 text-emerald-800",
    recover: "bg-amber-100 text-amber-800",
  };
  const label = mode === "build" ? "Build" : mode === "maintain" ? "Maintain" : "Recover";
  return <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${styles[mode]}`}>{label} mode</span>;
}

export default function Dashboard() {
  const [state, setState] = useState<AppState | null>(null);
  const [loading, setLoading] = useState(true);
  const [chatInput, setChatInput] = useState("");
  const [chatSending, setChatSending] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [constraintsDraft, setConstraintsDraft] = useState<string | null>(null);
  const [constraintsNotice, setConstraintsNotice] = useState<string | null>(null);

  // onboarding form
  const [goal, setGoal] = useState("");
  const [futureSelf, setFutureSelf] = useState("");
  const [values, setValues] = useState("");
  const [barriers, setBarriers] = useState("");
  const [constraints, setConstraints] = useState("");
  const [tone, setTone] = useState("gentle");
  const [habitName, setHabitName] = useState("");
  const [habitDomain, setHabitDomain] = useState("activity");
  const [ifThen, setIfThen] = useState("");
  const [tiny, setTiny] = useState("");
  const [small, setSmall] = useState("");
  const [standard, setStandard] = useState("");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/state", { cache: "no-store" });
    const data = await res.json();
    setState(data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function submitOnboard(e: React.FormEvent) {
    e.preventDefault();
    setNotice(null);
    const payload = {
      goal,
      identity: {
        futureSelf,
        values: values.split(",").map(s => s.trim()).filter(Boolean),
        barriers: barriers.split(",").map(s => s.trim()).filter(Boolean),
        constraints,
        tone,
      },
      habit: { name: habitName, domain: habitDomain, ifThen, tiny, small, standard },
    };
    const res = await fetch("/api/onboard", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!res.ok) { setNotice("Please fill required fields (goal, future self, habit)."); return; }
    await load();
  }

  async function checkIn(habitId: string, status: "done" | "smaller" | "skip") {
    let reason: string | undefined;
    let note: string | undefined;
    if (status === "skip") {
      reason = window.prompt("What's the main barrier? (time, energy, forgot, disruption, motivation, environment)", "time") || undefined;
      note = window.prompt("Anything you'd like to note? (optional)", "") || undefined;
    }
    await fetch("/api/checkin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ habitId, status, reason, note }) });
    setNotice(status === "skip" ? "Logged with compassion. NURA will adapt your plan—no judgment." : "Nice work. NURA is learning what supports you.");
    await load();
  }

  async function recover(action: "start" | "resolve") {
    const causeText = action === "start" ? (window.prompt("What got in the way? (time, energy, motivation, disruption...)", "") || "") : undefined;
    await fetch("/api/recover", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, causeText }) });
    await load();
  }

  async function sendChat(e: React.FormEvent) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setChatSending(true);
    await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: chatInput }) });
    setChatInput("");
    await load();
    setChatSending(false);
  }

  async function saveConstraints(e: React.FormEvent) {
    e.preventDefault();
    const text = constraintsText.trim();
    if (!text) { setConstraintsNotice("Enter a constraint to save."); return; }
    const res = await fetch("/api/identity", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ constraints: text }) });
    if (res.ok) {
      setConstraintsDraft(null);
      await load();
      setConstraintsNotice("Constraints saved — NURA will keep them in mind.");
    } else {
      setConstraintsNotice("Couldn’t save constraints. Try again.");
    }
  }

  const chat = state?.user?.chat || [];

  if (loading || !state) {
    return <div className="min-h-screen flex items-center justify-center text-slate-600">Loading NURA...</div>;
  }

  if (!state.user.onboarded) {
    return (
      <main className="min-h-screen bg-gradient-to-b from-teal-50 to-slate-50 p-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-slate-900">NURA</h1>
          <p className="text-slate-600 mt-1">Your adaptive health companion — understands behavior & identity, builds and maintains habits, and helps you recover from setbacks without judgment.</p>
          <form onSubmit={submitOnboard} className="mt-6 bg-white rounded-xl shadow-sm border p-6 space-y-5">
            <h2 className="text-xl font-semibold">1. You & your goal</h2>
            <div>
              <label className="block text-sm font-medium">Health/lifestyle goal *</label>
              <input className="mt-1 w-full border rounded-md p-2" value={goal} onChange={e=>setGoal(e.target.value)} placeholder="e.g. Have steady energy and move more" required />
            </div>
            <div>
              <label className="block text-sm font-medium">Future self / identity you want to grow into *</label>
              <input className="mt-1 w-full border rounded-md p-2" value={futureSelf} onChange={e=>setFutureSelf(e.target.value)} placeholder="e.g. a present, energetic parent" required />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium">Core values (comma separated)</label>
                <input className="mt-1 w-full border rounded-md p-2" value={values} onChange={e=>setValues(e.target.value)} placeholder="family, vitality, balance" />
              </div>
              <div>
                <label className="block text-sm font-medium">Common barriers (comma separated)</label>
                <input className="mt-1 w-full border rounded-md p-2" value={barriers} onChange={e=>setBarriers(e.target.value)} placeholder="time, low energy, motivation dips" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium">Constraints / context</label>
                <input className="mt-1 w-full border rounded-md p-2" value={constraints} onChange={e=>setConstraints(e.target.value)} placeholder="busy mornings, desk job, limited space" />
              </div>
              <div>
                <label className="block text-sm font-medium">Coach tone</label>
                <select className="mt-1 w-full border rounded-md p-2" value={tone} onChange={e=>setTone(e.target.value)}>
                  <option value="gentle">Gentle & compassionate</option>
                  <option value="direct">Clear & direct</option>
                  <option value="cheerful">Warm & encouraging</option>
                </select>
              </div>
            </div>

            <h2 className="text-xl font-semibold pt-2">2. First tiny habit (identity-aligned)</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium">Habit name *</label>
                <input className="mt-1 w-full border rounded-md p-2" value={habitName} onChange={e=>setHabitName(e.target.value)} placeholder="e.g. Morning stretch" required />
              </div>
              <div>
                <label className="block text-sm font-medium">Domain</label>
                <select className="mt-1 w-full border rounded-md p-2" value={habitDomain} onChange={e=>setHabitDomain(e.target.value)}>
                  <option value="activity">Activity</option>
                  <option value="nutrition">Nutrition</option>
                  <option value="sleep">Sleep</option>
                  <option value="stress">Stress / mindfulness</option>
                  <option value="wellbeing">General wellbeing</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium">If-then plan (cue)</label>
              <input className="mt-1 w-full border rounded-md p-2" value={ifThen} onChange={e=>setIfThen(e.target.value)} placeholder="After I pour my morning coffee, I will..." />
            </div>
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium">Tiny (MVR)</label>
                <input className="mt-1 w-full border rounded-md p-2" value={tiny} onChange={e=>setTiny(e.target.value)} placeholder="2-minute stretch" />
              </div>
              <div>
                <label className="block text-sm font-medium">Small</label>
                <input className="mt-1 w-full border rounded-md p-2" value={small} onChange={e=>setSmall(e.target.value)} placeholder="5-minute stretch" />
              </div>
              <div>
                <label className="block text-sm font-medium">Standard</label>
                <input className="mt-1 w-full border rounded-md p-2" value={standard} onChange={e=>setStandard(e.target.value)} placeholder="10-minute stretch" />
              </div>
            </div>
            {notice && <p className="text-amber-700 text-sm">{notice}</p>}
            <button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white font-medium px-5 py-2.5 rounded-md">Start with NURA</button>
          </form>
        </div>
      </main>
    );
  }

  const { user, insights, nextActions, reframe, mode } = state;
  const constraintsText = constraintsDraft !== null ? constraintsDraft : (user.identity.constraints || "");

  return (
    <main className="min-h-screen bg-slate-50 p-4 sm:p-6">
      <div className="max-w-6xl mx-auto space-y-5">
        <header className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">NURA <span className="text-slate-400 font-normal">| Adaptive Health Companion</span></h1>
            <p className="text-slate-600 text-sm">Goal: {user.goal} · Becoming: {user.identity.futureSelf}</p>
          </div>
          <div className="flex items-center gap-2"><Badge mode={mode} /><span className="text-xs text-slate-500">Continuously adapting to you</span></div>
        </header>

        {notice && <div className="bg-teal-50 border border-teal-200 text-teal-800 px-4 py-2 rounded-md text-sm">{notice}</div>}

        {user.recovery.active && (
          <section className="bg-amber-50 border border-amber-200 rounded-xl p-4">
            <h2 className="font-semibold text-amber-900">Recovery mode — no judgment</h2>
            <p className="text-amber-900/90 text-sm mt-1">{user.recovery.plan || "Let’s reset with the smallest possible step to rebuild momentum."}</p>
            <div className="mt-3 flex gap-2 flex-wrap">
              <button onClick={() => recover("resolve")} className="bg-amber600 bg-amber-600 hover:bg-amber-700 text-white text-sm px-3 py-1.5 rounded-md">I’m back on track</button>
              <span className="text-xs text-amber-800 self-center">Complete 2 small wins to ramp up gradually.</span>
            </div>
          </section>
        )}

        <div className="grid lg:grid-cols-3 gap-5">
          <section className="lg:col-span-2 space-y-5">
            <div className="bg-white rounded-xl border shadow-sm p-5">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h2 className="font-semibold text-lg">Constraints & context</h2>
                  <p className="text-sm text-slate-500 mt-1">What shapes your plan — your identity, barriers and hard-to-change context.</p>
                </div>
                <button type="button" onClick={() => setConstraintsDraft(user.identity.constraints || "")} className="text-xs text-teal-600 hover:underline">Edit</button>
              </div>
              <dl className="mt-3 grid sm:grid-cols-2 gap-3 text-sm">
                <div className="bg-slate-50 rounded-lg p-3">
                  <dt className="text-xs text-slate-500">Future self</dt>
                  <dd className="mt-0.5 text-slate-800">{user.identity.futureSelf || "—"}</dd>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 sm:col-span-2">
                  <dt className="text-xs text-slate-500">Values</dt>
                  <dd className="mt-0.5 flex flex-wrap gap-1.5">
                    {user.identity.values.length > 0 ? user.identity.values.map((v: string) => (
                      <span key={v} className="px-2 py-0.5 bg-indigo-50 text-indigo-800 rounded-md text-xs">Value: {v}</span>
                    )) : <span className="text-sm text-slate-400">—</span>}
                  </dd>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 sm:col-span-2">
                  <dt className="text-xs text-slate-500">Barriers</dt>
                  <dd className="mt-0.5 flex flex-wrap gap-1.5">
                    {user.identity.barriers.length > 0 ? user.identity.barriers.map((b: string) => (
                      <span key={b} className="px-2 py-0.5 bg-rose-50 text-rose-800 rounded-md text-xs">Barrier: {b}</span>
                    )) : <span className="text-sm text-slate-400">—</span>}
                  </dd>
                </div>
                <div className="bg-slate-50 rounded-lg p-3 sm:col-span-2">
                  <dt className="text-xs text-slate-500">Context / constraints</dt>
                  <dd className="mt-0.5 text-slate-800 whitespace-pre-line">{user.identity.constraints || "—"}</dd>
                </div>
              </dl>
              <form onSubmit={saveConstraints} className="mt-3 space-y-2">
                <input className="w-full border rounded-md p-2 text-sm" value={constraintsText} onChange={e => setConstraintsDraft(e.target.value)} placeholder="Add or edit constraints (comma separated): busy mornings, limited space, no evenings" />
                <div className="flex gap-2">
                  <button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white text-sm px-3 py-1.5 rounded-md">Save constraints</button>
                  {constraintsNotice && <span className="self-center text-xs text-teal-700">{constraintsNotice}</span>}
                </div>
              </form>
            </div>

            <div className="bg-white rounded-xl border shadow-sm p-5">
              <h2 className="font-semibold text-lg">Today’s adaptive next steps</h2>
              <p className="text-sm text-slate-600 mt-1">Sized to your behavior, context, and readiness — not fixed reminders.</p>
              <div className="mt-4 space-y-3">
                {nextActions.length === 0 && <p className="text-slate-500 text-sm">No active habits yet.</p>}
                {nextActions.map(a => (
                  <div key={a.habitId} className="border rounded-lg p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-medium">{a.habitName} <span className="text-xs uppercase tracking-wide text-slate-500">({a.level})</span></div>
                        <div className="text-slate-800 mt-0.5">{a.action}</div>
                        {a.ifThen && <div className="text-xs text-slate-500 mt-1">If-then: {a.ifThen}</div>}
                        <div className="text-xs text-teal-700 mt-1">{a.reason}</div>
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <button onClick={() => checkIn(a.habitId, "done")} className="bg-teal-600 hover:bg-teal-700 text-white text-sm px-3 py-1.5 rounded-md">Done</button>
                        <button onClick={() => checkIn(a.habitId, "smaller")} className="bg-teal-100 hover:bg-teal-200 text-teal-900 text-sm px-3 py-1.5 rounded-md">Did smaller</button>
                        <button onClick={() => checkIn(a.habitId, "skip")} className="bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm px-3 py-1.5 rounded-md">Skip / struggled</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {!user.recovery.active && (
                <button onClick={() => recover("start")} className="mt-4 text-sm text-amber-700 hover:underline">I need a compassionate reset</button>
              )}
            </div>

            <div className="bg-white rounded-xl border shadow-sm p-5">
              <h2 className="font-semibold text-lg">Behavior insights (understanding, not judgment)</h2>
              <div className="grid sm:grid-cols-4 gap-3 mt-3">
                <div className="bg-slate-50 rounded-lg p-3"><div className="text-xs text-slate-500">Follow-through (recent)</div><div className="text-xl font-semibold">{Math.round((insights.completionRate||0)*100)}%</div></div>
                <div className="bg-slate-50 rounded-lg p-3"><div className="text-xs text-slate-500">Check-ins</div><div className="text-xl font-semibold">{insights.done}/{insights.total}</div></div>
                <div className="bg-slate-50 rounded-lg p-3"><div className="text-xs text-slate-500">Momentum streak</div><div className="text-xl font-semibold">{insights.recentDoneStreak}d</div></div>
                <div className="bg-slate-50 rounded-lg p-3"><div className="text-xs text-slate-500">Setback risk</div><div className="text-xl font-semibold capitalize">{insights.risk}</div></div>
              </div>
              <div className="mt-3 text-sm text-slate-700">
                {insights.topSkipReasons.length > 0 ? (
                  <p>Recent friction patterns: <strong>{insights.topSkipReasons.join(", ")}</strong>. NURA adapts timing and difficulty around these.</p>
                ) : (
                  <p>NURA is learning your patterns from each check-in to adapt support over time.</p>
                )}
              </div>
            </div>

            <div className="bg-white rounded-xl border shadow-sm p-5">
              <h2 className="font-semibold text-lg">Identity & meaning</h2>
              <p className="text-slate-700 mt-1">{reframe}</p>
              <div className="mt-3 flex flex-wrap gap-2 text-sm">
                {user.identity.values?.map((v: string) => <span key={v} className="px-2 py-1 bg-indigo-50 text-indigo-800 rounded-md">Value: {v}</span>)}
                {user.identity.barriers?.map((b: string) => <span key={b} className="px-2 py-1 bg-rose-50 text-rose-800 rounded-md">Barrier: {b}</span>)}
              </div>
              {user.identity.constraints && <p className="text-sm text-slate-500 mt-2">Context/constraints: {user.identity.constraints}</p>}
            </div>
          </section>

          <aside className="space-y-5">
            <div className="bg-white rounded-xl border shadow-sm p-5 flex flex-col h-[520px]">
              <h2 className="font-semibold text-lg">NURA Coach (AI, non-judgmental)</h2>
              <p className="text-xs text-slate-500">Reflect, get adaptive suggestions, or work through barriers. Not medical advice.</p>
              <div className="mt-3 flex-1 overflow-y-auto space-y-3 pr-1">
                {chat.map((m: any, i: number) => (
                  <div key={i} className={`text-sm rounded-lg px-3 py-2 ${m.role === "assistant" ? "bg-slate-100 text-slate-800" : "bg-teal-600 text-white ml-6"}`}>
                    {m.content}
                  </div>
                ))}
              </div>
              <form onSubmit={sendChat} className="mt-3 flex gap-2">
                <input className="flex-1 border rounded-md p-2 text-sm" value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="e.g. I’m tired today, what should I do?" />
                <button disabled={chatSending} className="bg-slate-900 text-white px-3 py-2 rounded-md text-sm disabled:opacity-50">Send</button>
              </form>
            </div>

            <div className="bg-white rounded-xl border shadow-sm p-5 text-sm text-slate-700 space-y-2">
              <h2 className="font-semibold text-lg text-slate-900">How NURA adapts</h2>
              <ul className="list-disc pl-5 space-y-1">
                <li><strong>Understands behavior:</strong> learns from check-ins, patterns, and barriers.</li>
                <li><strong>Identity-aware:</strong> aligns actions with your values and future self.</li>
                <li><strong>Build & maintain:</strong> scales difficulty to sustain consistency.</li>
                <li><strong>Recover:</strong> detects setbacks, switches to minimum viable plans—no streak-shame.</li>
                <li><strong>Continuous loop:</strong> every interaction updates recommendations.</li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}
