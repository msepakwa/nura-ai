import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NURA – Adaptive Health Companion",
  description: "AI-powered adaptive health behavior and lifestyle management platform",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className="antialiased bg-slate-50 text-slate-900">{children}</body>
    </html>
  );
}
