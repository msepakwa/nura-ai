"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";

// Daily motivation rotates so the cover always greets you with a fresh line.
const DAILY_MOTIVATIONS = [
  "Small steps compound into momentum — start yours today.",
  "Every consistent day builds a future you didn't have yesterday.",
  "You don't have to be perfect; you just have to begin and keep going.",
  "Today is a chance to get one step closer to who you're becoming.",
  "Tiny actions, repeated daily, are how habits are truly made.",
  "Progress over time, not perfection in a single moment.",
  "Show up for the small win now and the big win becomes inevitable.",
  "Each morning is a fresh page — write a gentle opening chapter.",
  "Motion first: after starting, how you feel usually improves from there.",
  "Your best future self is being shaped by what you do today.",
  "Forgive a slow day, then get back to the rhythm you trust.",
  "If today is heavy, a single tiny step is still a step worth taking.",
];

// The motivation rotates once per day.
function dailyIndex() {
  return Math.floor(Date.now() / 86_400_000);
}

function partOfDay() {
  const hour = new Date().getHours();
  if (hour < 12) return "morning";
  if (hour < 17) return "afternoon";
  return "evening";
}

export default function CoverPage() {
  const [clock, setClock] = useState("");
  const motivation = DAILY_MOTIVATIONS[dailyIndex() % DAILY_MOTIVATIONS.length];
  const today = useMemo(
    () => new Date().toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long" }),
    []
  );

  useEffect(() => {
    const tick = () =>
      setClock(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" }));
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, []);

  const glints = [
    { left: "6%", top: "15%", opacity: 1 },
    { left: "92%", top: "6%", opacity: 0.8 },
    { left: "18%", top: "82%", opacity: 1 },
    { left: "88%", top: "55%", opacity: 0.7 },
    { left: "35%", top: "72%", opacity: 0.9 },
    { left: "70%", top: "90%", opacity: 1 },
  ];

  return (
    <main className="min-h-screen relative flex flex-col justify-between px-6 py-10 sm:px-10 md:px-14 overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="nura-blobA absolute -top-56 -right-56 w-[36rem] h-[36rem] rounded-full bg-gradient-to-tr from-teal-400/35 via-cyan-300/20 to-emerald-400/12 blur-3xl" />
        <div className="nura-blobB absolute bottom-0 left-32 w-[30rem] h-[30rem] rounded-full bg-gradient-to-tr from-violet-400/25 via-indigo-300/15 to-teal-200/8 blur-3xl" />
        <div className="nura-blobC absolute top-1/3 -left-32 w-64 h-64 rounded-full bg-white/6 blur-3xl" />
        {glints.map((g, i) => (
          <span
            key={i}
            className="absolute w-2.5 h-2.5 rounded-full bg-white/40 shadow-[0_0_14px_rgba(255,255,255,0.45)] animate-ping"
            style={{ left: g.left, top: g.top, animationDelay: `${i * 0.4 + 0.5}s`, opacity: g.opacity }}
          />
        ))}
      </div>

      <header className="relative flex flex-wrap items-center justify-between gap-2">
        <span className="text-lg font-semibold tracking-wide text-emerald-100">NURA</span>
        <span className="text-xs text-white/60">
          Good {partOfDay()} · {clock ? clock : "…"}
        </span>
      </header>

      <div className="relative flex flex-1 flex-col justify-center items-center text-center gap-6 max-w-4xl mx-auto">
        <p className="text-base sm:text-lg text-slate-100/85">Today, {today}</p>
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-tight text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.45)]">
          {motivation}
        </h1>
        <p className="max-w-2xl text-base sm:text-lg text-white/80">
          Your adaptive health companion — habits, progress and personalized support that adapts to you, every day.
        </p>
        <div className="pt-2">
          <Link
            href="/dashboard"
            className="group relative inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-400 to-teal-600 px-8 py-4 text-lg font-semibold text-slate-950 shadow-xl shadow-emerald-500/25 transition hover:scale-[1.04] hover:shadow-2xl hover:shadow-emerald-500/45"
          >
            Enter My Dashboard
            <span className="inline-flex items-center justify-center size-6 rounded-full bg-slate-950/10 text-white transition group-hover:translate-x-2">→</span>
          </Link>
        </div>
      </div>

      <footer className="relative pt-6 text-center text-xs text-white/45">
        NURA — your adaptive health companion
      </footer>
    </main>
  );
}
