import { UserState } from "./types";
import { getInsights, getNextActions, identityReframe, determineMode, recoverySuggestion, classifySetbackCause } from "./engine";

function includesAny(text: string, words: string[]) {
  const t = text.toLowerCase();
  return words.some(w => t.includes(w));
}

export function generateCoachReply(state: UserState, message: string): string {
  const mode = determineMode(state);
  const insights = getInsights(state);
  const actions = getNextActions(state);
  const primary = actions[0];

  if (!state.onboarded) {
    return "I'm NURA. Let's start by getting to know you—your goal, who you want to become, and what gets in the way. Complete onboarding and I'll tailor support to you (not generic reminders).";
  }

  if (includesAny(message, ["setback", "missed", "failed", "slipped", "can't", "cant", "give up", "quit"])) {
    const cause = classifySetbackCause(message);
    const habit = state.habits.find(h => h.active);
    return `No judgment—setbacks are signals, not failures. ${recoverySuggestion(cause, habit)} ${identityReframe(state)}`;
  }

  if (includesAny(message, ["tired", "exhausted", "no energy", "burnt", "burned"])) {
    const tiny = primary ? primary.action : "a 2-minute version of your habit";
    return `It makes sense to feel low on energy. Let's scale down, not stop: today’s compassionate step is **${tiny}**. Rest and small wins can coexist. ${identityReframe(state)}`;
  }

  if (includesAny(message, ["busy", "no time", "swamped", "overwhelmed"])) {
    const tiny = primary ? primary.action : "a 2-minute version of your habit";
    return `Busy days happen. We'll switch to a maintenance-sized step: **${tiny}**${primary?.ifThen ? ` (cue: ${primary.ifThen})` : ""}. Consistency matters more than size.`;
  }

  if (includesAny(message, ["why", "identity", "who am i", "not me"])) {
    const barriers = state.identity.barriers.length ? ` You mentioned barriers like ${state.identity.barriers.join(", ")}—we can design around them.` : "";
    return `We're focusing on identity, not willpower. You're working toward becoming ${state.identity.futureSelf || "a healthier version of yourself"}${state.identity.values.length ? `, guided by ${state.identity.values.join(", ")}` : ""}.${barriers} ${identityReframe(state)}`;
  }

  if (includesAny(message, ["plan", "today", "what should", "next", "recommend"])) {
    if (!primary) return "Add a habit and I’ll recommend your next best, right-sized action.";
    return `**Mode: ${mode.toUpperCase()}**. Your next best step: **${primary.habitName}** — ${primary.action}. ${primary.reason}${primary.ifThen ? `\nIf-then: ${primary.ifThen}` : ""}`;
  }

  if (includesAny(message, ["progress", "how am i", "insight", "stats"])) {
    const pct = Math.round(insights.completionRate * 100);
    const reason = insights.topSkipReasons[0] ? ` A common friction lately: ${insights.topSkipReasons[0]}.` : "";
    return `Over recent check-ins: ${pct}% follow-through (${insights.done}/${insights.total || 0}), current mode: ${mode}.${reason} ${identityReframe(state)}`;
  }

  // default reflective, adaptive response
  if (mode === "recover") {
    return `You're in recovery mode, and that's okay. Focus on the smallest win to rebuild momentum${primary ? `: **${primary.action}**` : ""}. What feels like the main barrier right now—time, energy, environment, or motivation?`;
  }
  if (primary) {
    return `I'm here with you. Based on your patterns, a good next step is **${primary.habitName}**: ${primary.action}. ${primary.reason} Want to do it, shrink it, or talk through a barrier?`;
  }
  return `Tell me what’s on your mind—your goal, a barrier, or how today feels—and I’ll adapt your plan with you. ${identityReframe(state)}`;
}
