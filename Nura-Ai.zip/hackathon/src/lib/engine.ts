import { CheckIn, Habit, Mode, UserState } from "./types";
import { todayStr } from "./store";

export interface BehaviorInsights {
  total: number;
  done: number;
  completionRate: number; // 0-1 over recent window
  recentMissStreak: number;
  recentDoneStreak: number;
  topSkipReasons: string[];
  risk: "low" | "medium" | "high";
}

export function getInsights(state: UserState, habitId?: string): BehaviorInsights {
  const checks = (habitId ? state.checkIns.filter(c => c.habitId === habitId) : state.checkIns)
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date));
  const recent = checks.slice(-14);
  const total = recent.length;
  const done = recent.filter(c => c.status === "done" || c.status === "smaller").length;
  const completionRate = total ? done / total : 0;

  let recentMissStreak = 0;
  for (let i = checks.length - 1; i >= 0; i--) {
    if (checks[i].status === "skip") recentMissStreak++; else break;
  }
  let recentDoneStreak = 0;
  for (let i = checks.length - 1; i >= 0; i--) {
    if (checks[i].status !== "skip") recentDoneStreak++; else break;
  }
  const reasonCounts: Record<string, number> = {};
  for (const c of recent.filter(c => c.status === "skip" && c.reason)) {
    const r = c.reason!.toLowerCase();
    reasonCounts[r] = (reasonCounts[r] || 0) + 1;
  }
  const topSkipReasons = Object.entries(reasonCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([r]) => r);

  let risk: BehaviorInsights["risk"] = "low";
  if (recentMissStreak >= 3 || (total >= 5 && completionRate < 0.35)) risk = "high";
  else if (recentMissStreak >= 1 || (total >= 4 && completionRate < 0.6)) risk = "medium";

  return { total, done, completionRate, recentMissStreak, recentDoneStreak, topSkipReasons, risk };
}

export function determineMode(state: UserState): Mode {
  if (state.recovery.active) return "recover";
  const insights = getInsights(state);
  if (insights.risk === "high") return "recover";
  if (insights.recentDoneStreak >= 5 && insights.completionRate >= 0.7) return "maintain";
  return "build";
}

export function classifySetbackCause(reason?: string, note?: string): string {
  const text = `${reason || ""} ${note || ""}`.toLowerCase();
  if (/tired|exhaust|sleep|energy|burn/.test(text)) return "energy";
  if (/busy|work|meeting|time|no time|schedule/.test(text)) return "time";
  if (/forgot|remember/.test(text)) return "forgetfulness";
  if (/travel|sick|ill|injur|pain|family|kids/.test(text)) return "disruption";
  if (/motivat|don't feel|didn't feel|not me|lazy|pointless/.test(text)) return "motivation/identity";
  if (/place|gym|weather|space|environment/.test(text)) return "environment";
  return "unspecified";
}

export function recoverySuggestion(cause: string, habit?: Habit): string {
  const tiny = habit?.tiny || "a 2-minute version of your habit";
  switch (cause) {
    case "energy": return `Energy was low. For 24–72h, do only the minimum: ${tiny}. Rest counts as support.`;
    case "time": return `Time was tight. Shrink the habit to ${tiny} and attach it to an existing routine.`;
    case "forgetfulness": return `It slipped your mind. Use an if-then cue and a single gentle prompt at a reliable time.`;
    case "disruption": return `Life disrupted your plan. That's normal. Restart with ${tiny} when ready—no catch-up needed.`;
    case "motivation/identity": return `This felt misaligned. Reconnect to your future self: do ${tiny} as proof of who you're becoming, not a test.`;
    case "environment": return `Your environment got in the way. Make ${tiny} possible where you are (no special setup).`;
    default: return `Setbacks happen. Reset with ${tiny}—smallest step, no judgment, then rebuild gradually.`;
  }
}

export function recommendLevel(state: UserState, habit: Habit): "tiny" | "small" | "standard" {
  const insights = getInsights(state, habit.id);
  const mode = state.recovery.active ? "recover" : determineMode(state);
  if (mode === "recover" || insights.risk === "high" || insights.recentMissStreak >= 2) return "tiny";
  if (mode === "maintain" && insights.completionRate > 0.8 && insights.recentDoneStreak >= 5) return "standard";
  if (insights.completionRate >= 0.6) return "small";
  return "tiny";
}

export interface NextAction {
  habitId: string;
  habitName: string;
  level: "tiny" | "small" | "standard";
  action: string;
  ifThen: string;
  reason: string;
  mode: Mode;
}

export function getNextActions(state: UserState): NextAction[] {
  const mode = determineMode(state);
  const actions: NextAction[] = [];
  for (const habit of state.habits.filter(h => h.active)) {
    const level = recommendLevel(state, habit);
    const action = level === "tiny" ? habit.tiny : level === "small" ? habit.small : habit.standard;
    let reason = "Sized to your current rhythm.";
    if (mode === "recover") reason = "Recovery mode: smallest win to rebuild momentum.";
    else if (mode === "maintain") reason = "Maintenance mode: protect consistency with a sustainable dose.";
    else if (getInsights(state, habit.id).risk === "medium") reason = "A lighter step to keep you moving without overload.";
    actions.push({ habitId: habit.id, habitName: habit.name, level, action, ifThen: habit.ifThen, reason, mode });
  }
  return actions.slice(0, 3);
}

export function identityReframe(state: UserState): string {
  const fsSelf = state.identity.futureSelf || "your healthier self";
  const val = state.identity.values[0];
  const base = `Each small action is evidence that you are becoming ${fsSelf}.`;
  if (val) return `${base} This honors your value of ${val}.`;
  return base;
}

export function applyCheckInAdaptation(state: UserState, checkIn: CheckIn): UserState {
  // mutate-friendly copy assumptions handled by caller; update habit levels and recovery
  const habit = state.habits.find(h => h.id === checkIn.habitId);
  if (checkIn.status === "skip") {
    const cause = classifySetbackCause(checkIn.reason, checkIn.note);
    const misses = getInsights(state, checkIn.habitId).recentMissStreak; // includes this in effect? state already has it
    if (misses >= 2) {
      state.recovery.active = true;
      state.recovery.cause = cause;
      state.recovery.startedAt = state.recovery.startedAt || new Date().toISOString();
      state.recovery.plan = recoverySuggestion(cause, habit);
      state.recovery.rampStep = 0;
      if (habit) habit.currentLevel = "tiny";
    } else if (habit) {
      habit.currentLevel = "tiny";
    }
  } else {
    // success: progress recovery ramp or maintain
    if (state.recovery.active) {
      state.recovery.rampStep = (state.recovery.rampStep || 0) + 1;
      if (state.recovery.rampStep >= 2) {
        state.recovery.active = false;
        state.recovery.cause = undefined;
        state.recovery.plan = undefined;
        state.recovery.rampStep = 0;
      } else if (habit) {
        habit.currentLevel = "small";
      }
    } else if (habit) {
      const insights = getInsights(state, habit.id);
      if (insights.completionRate > 0.8 && insights.recentDoneStreak >= 4) habit.currentLevel = "standard";
      else if (insights.completionRate > 0.5) habit.currentLevel = "small";
    }
  }
  state.mode = determineMode(state);
  return state;
}
