import fs from "fs";
import path from "path";
import { DB, UserState } from "./types";

const DATA_DIR = path.join(process.cwd(), "data");
const DB_PATH = path.join(DATA_DIR, "db.json");

function defaultUser(): UserState {
  return {
    onboarded: false,
    goal: "",
    identity: {
      futureSelf: "",
      values: [],
      barriers: [],
      constraints: "",
      tone: "gentle",
    },
    habits: [],
    checkIns: [],
    reflections: [],
    recovery: { active: false, rampStep: 0 },
    mode: "build",
  };
}

function defaultDB(): DB {
  return { user: defaultUser(), chat: [] };
}

export function readDB(): DB {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    if (!fs.existsSync(DB_PATH)) {
      const db = defaultDB();
      fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
      return db;
    }
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    const parsed = JSON.parse(raw) as DB;
    // basic migration safety
    if (!parsed.user) parsed.user = defaultUser();
    if (!parsed.chat) parsed.chat = [];
    return parsed;
  } catch {
    return defaultDB();
  }
}

export function writeDB(db: DB) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
}

export function updateDB(mutator: (db: DB) => void): DB {
  const db = readDB();
  mutator(db);
  writeDB(db);
  return db;
}

export function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
