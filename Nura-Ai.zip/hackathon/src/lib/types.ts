export type Mode = "build" | "maintain" | "recover";

export interface IdentityProfile {
  futureSelf: string;
  values: string[];
  barriers: string[];
  constraints: string;
  tone: "gentle" | "direct" | "cheerful";
}

export interface Habit {
  id: string;
  name: string;
  domain: string;
  ifThen: string;
  tiny: string; // minimum viable version
  small: string;
  standard: string;
  currentLevel: "tiny" | "small" | "standard";
  active: boolean;
  createdAt: string;
}

export interface CheckIn {
  id: string;
  habitId: string;
  date: string; // YYYY-MM-DD
  status: "done" | "smaller" | "skip";
  reason?: string;
  note?: string;
  levelDone?: "tiny" | "small" | "standard";
  createdAt: string;
}

export interface Reflection {
  id: string;
  date: string;
  text: string;
  createdAt: string;
}

export interface RecoveryState {
  active: boolean;
  startedAt?: string;
  cause?: string;
  plan?: string;
  rampStep: number; // 0 = MVR
}

export interface UserState {
  onboarded: boolean;
  goal: string;
  identity: IdentityProfile;
  habits: Habit[];
  checkIns: CheckIn[];
  reflections: Reflection[];
  recovery: RecoveryState;
  mode: Mode;
}

export interface CoachMessage {
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

export interface DB {
  user: UserState;
  chat: CoachMessage[];
}
